<template>
    <div :class="colorClass">
        <svg :width="width" :height="height" :viewBox="'0 0 ' + width + ' ' + height" fill="none"
            xmlns="http://www.w3.org/2000/svg">
            <path
                d="M6.25 6.39167V5.58334C6.25 3.70834 7.75833 1.86667 9.63333 1.69167C11.8667 1.47501 13.75 3.23334 13.75 5.42501V6.57501"
                stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"
                stroke-linejoin="round" />
            <path
                d="M7.5001 18.3333H12.5001C15.8501 18.3333 16.4501 16.9916 16.6251 15.3583L17.2501 10.3583C17.4751 8.32496 16.8918 6.66663 13.3334 6.66663H6.66677C3.10843 6.66663 2.5251 8.32496 2.7501 10.3583L3.3751 15.3583C3.5501 16.9916 4.1501 18.3333 7.5001 18.3333Z"
                stroke="currentColor" stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round"
                stroke-linejoin="round" />
            <path d="M12.9128 10H12.9203" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                stroke-linejoin="round" />
            <path d="M7.07884 10H7.08632" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                stroke-linejoin="round" />
        </svg>
    </div>
</template>

<script setup>

const props = defineProps({
    colorClass: {
        type: String,
        default: 'text-primary'
    },
    width: {
        type: String,
        default: '20'
    },
    height: {
        type: String,
        default: '20'
    }
});
</script>
