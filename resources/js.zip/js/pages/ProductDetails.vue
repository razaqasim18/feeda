<template>
    <div class="main-container">
        <div v-show="!isLoading" class="grid grid-cols-1 xl:grid-cols-4">
            <div class="col-span-1 xl:col-span-3 lg:pr-6">
                <div class="flex items-center gap-2 pt-4 overflow-hidden">
                    <router-link to="/" class="w-6 h-6">
                        <HomeIcon class="w-5 h-5 text-slate-600" />
                    </router-link>

                    <div class="w-full overflow-hidden grow">
                        <div class="space-x-1 text-sm font-normal truncate text-slate-600">
                            <router-link to="/">{{ $t('Home') }}</router-link>
                            <span>/</span>
                            <span>{{ product . name }} </span>
                        </div>
                    </div>
                </div>

                <div class="flex flex-wrap gap-4 mt-6 lg:flex-nowrap">
                    <div class="lg:w-[480px] w-full">
                        <div class="w-full">
                            <div class="px-6 border bg-slate-50 rounded-xl border-slate-100">

                                <swiper v-show="showCustom" id="customdiv" :spaceBetween="10" :thumbs="{ swiper: thumbsSwiper }"
                                    :modules="modules" class="product-details-slider">
                                    <swiper-slide class="max-h-[448px] h-auto">
                                        <div class="h-full zoom-container" @mousemove="handleMouseMove"
                                            @mouseleave="resetZoom" @touchstart="handleMouseMove"
                                            @touchmove="handleMouseMove" @touchend="resetZoom">
                                            <img id="main-thumbnail" :src="selectedImage" alt="thumbnail"
                                                class="object-contain w-full h-full zoom-image" />
                                        </div>
                                    </swiper-slide>
                                </swiper>

                                <swiper v-show="!showCustom" id="swipperdiv" :spaceBetween="10" :thumbs="{ swiper: thumbsSwiper }"
                                    :modules="modules" class="product-details-slider">
                                    <swiper-slide v-for="thumbnail in product.thumbnails" :key="thumbnail.id"
                                        class="max-h-[448px] h-auto">

                                        <div v-if="thumbnail.thumbnail" class="h-full zoom-container"
                                            @mousemove="handleMouseMove" @mouseleave="resetZoom"
                                            @touchstart="handleMouseMove" @touchmove="handleMouseMove"
                                            @touchend="resetZoom">
                                            <img :src="thumbnail.thumbnail" alt="thumbnail"
                                                class="object-contain w-full h-full zoom-image" />
                                        </div>

                                        <div v-else class="flex items-center justify-center w-full h-full bg-slate-200">
                                            <video v-if="thumbnail.type == 'file'" controls class="w-full">
                                                <source :src="thumbnail.url" type="video/mp4">
                                            </video>
                                            <div v-else v-html="thumbnail.url" class="w-full overflow-hidden"
                                                ref="iframeContainer"></div>
                                        </div>
                                    </swiper-slide>
                                </swiper>

                            </div>
                            <div class="px-1 mt-2">
                                <swiper @swiper="setThumbsSwiper" :spaceBetween="10" :slidesPerView="4"
                                    :freeMode="true" :navigation="true" :watchSlidesProgress="true"
                                    :modules="modules" class="product-details-thumbnail">
                                    <swiper-slide v-for="thumbnail in product.thumbnails" :key="thumbnail.id">
                                        <img v-if="thumbnail.thumbnail" :src="thumbnail.thumbnail" alt=""
                                            class="object-cover w-full h-full changeshowcolordiv" />

                                        <div v-else
                                            class="flex items-center justify-center w-full h-full bg-slate-200 changeshowcolordiv">
                                            <video v-if="thumbnail.type == 'file'" class="w-full h-full">
                                                <source :src="thumbnail.url" type="video/mp4">
                                            </video>
                                            <div v-else
                                                class="flex items-center justify-center w-full h-full overflow-hidden">
                                                <img :src="'/assets/icons/video-player.svg'" alt=""
                                                    width="70" height="70">
                                            </div>
                                        </div>

                                    </swiper-slide>
                                </swiper>
                            </div>
                        </div>
                    </div>

                    <div class="w-full sm:w-auto">
                        <!-- Flash Sale  -->
                        <div v-if="flashSale"
                            class="bg-slate-100 mb-3 sm:mb-6 rounded-lg sm:rounded-[44px] flex items-center justify-start gap-2 sm:gap-5 overflow-hidden flex-col sm:flex-row">
                            <div
                                class="w-full px-4 py-2 sm:px-8 bg-gradient-to-l from-primary to-primary-800 sm:w-auto">
                                <div class="text-sm font-bold leading-normal text-white sm:text-base">
                                    {{ $t('Flash Sale') }}
                                </div>
                            </div>

                            <div class="flex flex-wrap items-center justify-center h-full pb-2 sm:pb-0">
                                <div class="pr-2 text-sm font-normal leading-tight text-center text-primary">
                                    {{ $t('Ending in') }}
                                </div>

                                <!-- Days, Hours, Minutes, Seconds -->
                                <div class="flex items-center justify-center gap-1 text-white">
                                    <div v-if="endDay > 0" class="inline-flex items-center justify-center gap-1 p-1">
                                        <div
                                            class="text-center text-primary text-base font-semibold font-['Inter'] leading-none">
                                            {{ endDay }}
                                        </div>
                                        <div
                                            class="text-center text-[#687387] text-[9.14px] font-normal font-['Inter'] leading-none">
                                            {{ $t('Days') }}
                                        </div>
                                    </div>

                                    <span v-if="endDay > 0" class="text-base font-bold text-black">:</span>
                                    <div class="inline-flex items-center justify-center gap-1 p-1">
                                        <div class="text-center text-primary text-base font-semibold font-['Inter']">
                                            {{ endHour }}
                                        </div>
                                        <div
                                            class="text-center text-[#687387] text-[9.14px] font-normal font-['Inter'] leading-none">
                                            {{ $t('Hours') }}
                                        </div>
                                    </div>

                                    <span class="text-base font-bold text-black">:</span>
                                    <div class="inline-flex items-center justify-center gap-1 p-1">
                                        <div class="text-center text-primary text-base font-semibold font-['Inter']">
                                            {{ endMinute }}
                                        </div>
                                        <div
                                            class="text-center text-[#687387] text-[9.14px] font-normal font-['Inter'] leading-none">
                                            {{ $t('Minutes') }}
                                        </div>
                                    </div>

                                    <span v-if="endDay <= 0" class="text-base font-bold text-black">:</span>
                                    <div v-if="endDay <= 0" class="inline-flex items-center justify-center gap-1 p-1">
                                        <div class="text-center text-primary text-base font-semibold font-['Inter']">
                                            {{ endSecond }}
                                        </div>
                                        <div
                                            class="text-center text-[#687387] text-[9.14px] font-normal font-['Inter'] leading-none">
                                            {{ $t('Seconds') }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Flash Sale -->

                        <!-- Brand -->
                        <span class="text-primary text-xs font-normal leading-none px-1.5 py-1 bg-primary-50 rounded">
                            {{ product . brand ?? 'Unknown Brand' }}
                        </span>

                        <div class="block md:hidden">
                            <!-- Size -->
                            <div v-if="product.sizes?.length > 0" class="flex items-center gap-3 py-4">
                                <div class="w-[40px] md:w-[88px] text-slate-600 text-base font-normal leading-normal">
                                    {{ $t('Size') }}
                                </div>

                                <div class="flex flex-wrap items-center gap-3">
                                    <div v-for="size in product.sizes" :key="size.id" class="relative">
                                        <input type="radio" name="size" class="hidden peer"  :id="'size-' + size.id" :value="Number(size.id)"
                                            v-model.number="formData.size" :disabled="size.quantity <= 0" />
                                        <label :for="'size-' + size.id"
                                            :class="[
                                                'px-2 py-1 flex justify-center items-center border-2 rounded-md',
                                                size.quantity <= 0 ?
                                                'cursor-not-allowed border-slate-300 bg-gray-200 opacity-60 disabled' :
                                                'cursor-pointer border-slate-200 peer-checked:border-primary peer-checked:bg-primary-100',
                                           ]">
                                            {{ size.name }}
                                        </label>
                                    </div>
                                    <div v-if="!product.sizes" class="text-base font-normal text-slate-500">
                                        {{ $t('N/A') }}
                                    </div>
                                </div>
                            </div>

                            <!-- Color -->
                            <div v-if="product.colors?.length > 0" class="flex items-center gap-3 py-4">
                                <div class="w-[40px] md:w-[88px] text-slate-600 text-base font-normal leading-normal">
                                    {{ $t('Color') }}
                                </div>

                                <div class="flex flex-wrap items-center gap-3">
                                    <div v-for="color in product.colors" :key="color.id" class="relative">
                                        <input @change="updateImage(color.image)" type="radio" name="color"
                                            class="hidden peer" :id="'color-' + color.id" :value="Number(color.id)"
                                            v-model.number="formData.color" :disabled="color.quantity <= 0">

                                        <label :for="'color-' + color.id"
                                            :class="[
                                                'px-2 py-1 flex justify-center items-center border-2 rounded-md',
                                                color.quantity <= 0 ?
                                                  'cursor-not-allowed border-slate-300 bg-gray-200 opacity-60 disabled' :
                                                'cursor-pointer border-slate-200 peer-checked:border-primary peer-checked:bg-primary-100',
                                           ]">
                                            {{ color.name }}
                                        </label>
                                    </div>


                                    <div v-if="!product.colors" class="text-base font-normal text-slate-500">
                                        {{ $t('N/A') }}
                                    </div>
                                </div>

                            </div>
                        </div>
                        &nbsp;
                        <!-- Title -->
                        <label v-if="product?.quantity === 0"
                            class="px-2 py-1 text-xs font-semibold text-white uppercase bg-gray-500"> Sold Out
                        </label>
                        <div class="mt-3 text-2xl font-medium leading-normal text-slate-950">
                            {{ product . name }}
                        </div>

                        <!-- Short Description -->
                        <div class="mt-2 text-base font-normal leading-normal text-slate-700">
                            {{ product . short_description }}
                        </div>

                        <!-- Rating  review, sold and share -->
                        <div class="flex flex-wrap items-center justify-start gap-4 py-5 border-b border-slate-200">
                            <!-- rating -->
                            <!--<div class="flex items-center gap-2">-->
                            <!--    <div class="flex">-->
                            <!--        <StarIcon class="w-6 h-6 text-amber-500" />-->
                            <!--        <StarIcon v-for="i in 4" :key="i" class="hidden w-6 h-6 2xl:block" :class="i < product.rating ? 'text-amber-500' : 'text-gray-300'-->
                                                        <!--            " />-->
                            <!--    </div>-->
                            <!--    <div class="text-base font-bold text-slate-800">-->
                            <!--        {{ product . rating }}-->
                            <!--    </div>-->
                            <!-- Review -->
                            <!--    <div class="text-base font-normal text-slate-500">-->
                            <!--        {{ product . total_reviews }} {{ $t('Review') }}-->
                            <!--    </div>-->
                            <!--</div>-->

                            <!--<div class="w-[1px] h-4 bg-slate-200"></div>-->

                            <!-- Sold -->
                            <!--<div class="text-base font-normal leading-normal text-slate-800">-->
                            <!--    {{ product . total_sold }} {{ $t('Sold') }}-->
                            <!--</div>-->

                            <div class="w-[1px] h-4 bg-slate-200"></div>

                            <!-- Share -->
                            <button @click="copyUrl" class="flex items-center gap-2 border-none">
                                <ShareIcon class="w-[18px] text-slate-600" />
                                <span class="text-base font-normal leading-normal text-slate-800">
                                    {{ $t('Share') }}
                                </span>
                            </button>

                            <div class="w-[1px] h-4 bg-slate-200"></div>

                            <!-- Heart Icon -->
                            <button class="border-none" @click="favoriteAddOrRemove">
                                <HeartIcon v-if="!product.is_favorite" class="w-6 h-6 text-slate-600" />
                                <HeartIconFill v-else class="w-6 h-6 text-red-500" />
                            </button>
                        </div>

                        <!-- Price part -->
                        <div class="flex flex-wrap items-center gap-3 py-4 border-b border-slate-200">
                            <!-- discount Price -->
                            <div class="text-3xl font-bold leading-9 text-primary">
                                {{ masterStore . showCurrency(parseFloat(productPrice) . toFixed(2)) }}
                            </div>

                            <!-- Price -->
                            <div v-if="product.discount_price > 0"
                                class="text-2xl font-normal leading-loose line-through text-slate-400">
                                {{ masterStore . showCurrency(parseFloat(mainPrice) . toFixed(2)) }}
                            </div>

                            <!-- discount -->
                            <div v-if="discountPercentage > 0"
                                class="px-2 py-1 text-base font-medium text-white bg-red-500 rounded-2xl">
                                {{ discountPercentage }}% {{ $t('OFF') }}
                            </div>
                        </div>
                        <!-- mobile -->
                        <div class="hidden md:block">
                            <!-- Size -->
                            <div v-if="product.sizes?.length > 0" class="flex items-center gap-3 py-4">
                                <div class="w-[40px] md:w-[88px] text-slate-600 text-base font-normal leading-normal">
                                    {{ $t('Size') }}
                                </div>

                                <div class="flex flex-wrap items-center gap-3">
                                    <div v-for="size in product.sizes" :key="size.id" class="relative">
                                        <input type="radio" name="size" :id="'size-' + size.id"
                                            class="hidden peer" :value="size.id" v-model="formData.size"
                                            :disabled="size.quantity <= 0" />
                                        <label :for="'size-' + size.id"
                                         :class="[
                                                'px-2 py-1 flex justify-center items-center border-2 rounded-md',
                                                size.quantity <= 0 ?
                                                'cursor-not-allowed border-slate-300 bg-gray-200 opacity-60 disabled' :
                                                'cursor-pointer border-slate-200 peer-checked:border-primary peer-checked:bg-primary-100',
                                            ]">
                                            {{ size.name }}
                                        </label>
                                    </div>
                                    <div v-if="!product.sizes" class="text-base font-normal text-slate-500">
                                        {{ $t('N/A') }}
                                    </div>
                                </div>
                            </div>

                            <!-- Color -->
                            <div v-if="product.colors?.length > 0" class="flex items-center gap-3 py-4">
                                <div class="w-[40px] md:w-[88px] text-slate-600 text-base font-normal leading-normal">
                                    {{ $t('Color') }}
                                </div>

                                <div class="flex flex-wrap items-center gap-3">
                                    <div v-for="color in product.colors" :key="color.id" class="relative">
                                        <input @change="updateImage(color.image)" type="radio" name="color"
                                            :id="'color-' + color.id" class="hidden peer change-image-btn"
                                            :value="color.id" v-model="formData.color"
                                            :disabled="color.quantity <= 0" />

                                        <label :for="'color-' + color.id"
                                            :class="[
                                                'px-2 py-1 flex justify-center items-center border-2 rounded-md',
                                                color.quantity <= 0 ?
                                                'cursor-not-allowed border-slate-300 bg-gray-200 opacity-60 disabled' :
                                                'cursor-pointer border-slate-200 peer-checked:border-primary peer-checked:bg-primary-100',
                                            ]">
                                            {{ color.name }}
                                        </label>
                                    </div>


                                    <div v-if="!product.colors" class="text-base font-normal text-slate-500">
                                        {{ $t('N/A') }}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div v-if="product?.quantity > 0" class="flex flex-wrap gap-4">
                            <!-- Quantity Increase Or Decrease -->
                            <!-- <div v-if="cartProduct"
                                class="p-2 rounded-[10px] border border-slate-100 inline-flex gap-4">
                                <button class="p-2 rounded bg-slate-200" @click="decrementQty">
                                    <MinusIcon class="w-6 h-6 text-slate-800" />
                                </button>

                                <div
                                    class="flex items-center justify-center w-6 text-base font-medium leading-normal text-center text-slate-950">
                                    {{ cartProduct . quantity }}
                                </div>

                                <button class="p-2 rounded bg-slate-100" @click="incrementQty">
                                    <PlusIcon class="w-6 h-6 text-slate-800" />
                                </button>
                            </div> -->

                            <!-- Add to Cart -->
                            <!-- <span v-if="product?.quantity > 0"> -->
                            <button
                                class="grow max-w-56 justify-center items-center text-primary flex gap-2 px-6 py-4 rounded-[10px] border border-primary"
                                @click="addToCart">
                                <div class="w-5 h-5">
                                    <BagIcon />
                                </div>
                                <div class="text-base font-medium leading-normal">
                                    {{ $t('Add to Cart') }}
                                </div>
                            </button>

                            <!-- Buy Now -->
                            <button
                                class="grow text-white bg-primary px-6 py-4 rounded-[10px] border border-primary max-w-[50%]"
                                @click="buyNow">
                                <span class="text-base font-medium leading-normal">
                                    {{ $t('Buy Now') }}
                                </span>
                            </button>
                            <!-- </span>  -->

                        </div>
                        <div v-else class="flex flex-wrap gap-4">
                            <button
                                class="grow max-w-100 justify-center items-center text-primary flex gap-2 px-6 py-4 rounded-[10px] bg-gray-500 text-white text-xs px-2 py-1 font-semibold uppercase cursor-not-allowed">
                                Sold Out
                            </button>
                        </div>
                    </div>
                </div>

                <div class="block w-full pt-6 xl:hidden border-slate-200">
                    <ProductDetailsRightSide :product="product" :popularProducts="popularProducts" />
                </div>

                <div class="flex flex-wrap items-center gap-8 mt-3 mb-4 border-b xl:my-6">
                    <button class="py-3 text-base font-medium leading-normal transition border-b"
                        :class="aboutProduct
                            ?
                            'text-primary border-primary' :
                            'text-slate-600 border-transparent'"
                        @click="aboutProduct = true; review = false;">
                        {{ $t('About Product') }}
                    </button>

                    <!-- <button class="py-3 text-base font-medium leading-normal transition border-b" :class="review
                        ?
                        'text-primary border-primary' :
                        'text-slate-600 border-transparent'" @click="showReview()">
                        {{ $t('Reviews') }}
                    </button> -->
                </div>

                <!-- About Product -->
                <div v-if="aboutProduct" class="description">
                    <div class="w-full m-0 prose max-w-none" v-html="product.description"></div>
                </div>

                <!-- Reviews -->
                <!--<div v-if="review" class="">
                    <div class="mb-4 text-lg font-medium leading-loose text-slate-950 lg:text-2xl">
                        {{ $t('Rating and Review') }}
                    </div> -->

                <!-- Review Rating percentage -->
                <!-- <div class="max-w-2xl">
                        <ReviewRatings :reviewRatings="averageRatings.percentages"
                            :averageRating="averageRatings?.rating" :totalReview="averageRatings.total_review" />
                    </div> -->

                <!-- Reviews -->
                <!-- <div class="mt-6 border-t border-slate-200">
                        <div class="mt-4 text-lg font-medium leading-loose lg:mt-6 text-slate-950 lg:text-2xl">
                            {{ $t('Reviews') }}
                        </div>

                        <div class="mt-6 space-y-6">
                            <Review v-for="review in reviews" :key="review.id" :review="review" />
                        </div> -->

                <!-- pagination's -->
                <!-- <div class="flex flex-wrap items-center justify-between w-full gap-4 mt-8">
                            <div class="text-base font-normal leading-normal text-slate-800">
                                {{ $t('Showing') }} {{ perPage * (currentPage - 1) + 1 }}
                                {{ $t('to') }}
                                {{ perPage * (currentPage - 1) + reviews . length }}
                                {{ $t('of') }} {{ totalReviews }} {{ $t('results') }}
                            </div>
                            <div>
                                <vue-awesome-paginate :total-items="totalReviews" :items-per-page="perPage"
                                    type="button" :max-pages-shown="3" v-model="currentPage"
                                    :hide-prev-next-when-ends="true" @click="onClickHandler" />
                            </div>
                        </div>
                    </div>
                </div>-->
            </div>

            <!-- Right side -->
            <div class="hidden w-full h-full col-span-1 pt-6 xl:block xl:pt-16 border-slate-200 xl:pb-6"
                :class="masterStore.langDirection == 'rtl' ? 'xl:pr-8 xl:border-r' : 'xl:pl-8 xl:border-l'">
                <ProductDetailsRightSide :product="product" :popularProducts="popularProducts" />
            </div>
        </div>

        <!-- Similar Products -->
        <div v-if="relatedProducts.length > 0 && !isLoading">
            <div class="mt-4 text-lg font-bold leading-9 xl:mt-6 text-slate-800 md:text-2xl lg:text-3xl">
                {{ $t('Similar Products') }}
            </div>

            <div
                class="grid items-start grid-cols-2 gap-3 my-6 sm:grid-cols-2 md:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 sm:gap-6">
                <div v-for="product in relatedProducts" :key="product.id">
                    <ProductCard :product="product" />
                </div>
            </div>
        </div>

        <!-- page loader -->
        <div v-if="isLoading" class="grid grid-cols-1 xl:grid-cols-4">
            <div class="col-span-1 xl:col-span-3 lg:pr-6">
                <div class="flex items-center gap-2 pt-6 overflow-hidden">
                    <SkeletonLoader class="w-40 h-4" />
                </div>
                <div class="flex flex-wrap gap-4 mt-6 lg:flex-nowrap">
                    <div class="lg:w-[480px] w-full lg:shrink-0">
                        <SkeletonLoader class="w-full rounded-lg h-52 md:h-80" />

                        <div class="flex flex-grow gap-3 mt-4">
                            <SkeletonLoader v-for="i in 4" class="w-20 h-16 grow" />
                        </div>
                        <div class="flex flex-col gap-3 mt-6">
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-10/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-full h-3 rounded-xl" />
                        </div>
                        <div class="flex flex-col gap-4 mt-4">
                            <SkeletonLoader v-for="i in 3" class="w-full h-20 rounded-lg" />
                        </div>
                    </div>

                    <div class="w-full pb-4">
                        <div class="flex flex-col gap-3">
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-10/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-full h-3 rounded-xl" />
                        </div>

                        <div class="flex flex-col gap-4 mt-4">
                            <SkeletonLoader v-for="i in 3" class="w-full h-20 rounded-lg" />
                        </div>

                        <div class="flex flex-col gap-3 mt-4">
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-10/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-11/12 h-3 rounded-xl" />
                            <SkeletonLoader class="w-full h-3 rounded-xl" />
                        </div>
                        <div class="flex flex-col gap-4 mt-4">
                            <SkeletonLoader v-for="i in 2" class="w-full h-20 rounded-lg md:h-36" />
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right side -->
            <div
                class="hidden w-full h-full col-span-1 pt-6 xl:block xl:pt-16 xl:pl-8 xl:border-l border-slate-200 xl:pb-6">
                <div class="flex flex-col gap-4 mt-4">
                    <SkeletonLoader v-for="i in 5" class="w-full h-20 rounded-lg md:h-36" />
                </div>
            </div>
        </div>
        <!-- end loader -->
    </div>
</template>


<script setup>
    import {
        nextTick,
        onMounted,
        onUnmounted,
        ref,
        watch
    } from "vue";
    import {
        useRoute,
        useRouter
    } from "vue-router";
    import ProductDetailsRightSide from "../components/ProductDetailsRightSide.vue";
    import ToastSuccessMessage from "../components/ToastSuccessMessage.vue";
    import BagIcon from "../icons/Bag.vue";
    import {
        useMaster
    } from "../stores/MasterStore";

    import {
        HeartIcon,
        HomeIcon,
        MinusIcon,
        PlusIcon,
        ShareIcon
    } from "@heroicons/vue/24/outline";
    import {
        HeartIcon as HeartIconFill,
        StarIcon
    } from "@heroicons/vue/24/solid";
    import {
        FreeMode,
        Navigation,
        Thumbs
    } from "swiper/modules";
    import {
        Swiper,
        SwiperSlide
    } from "swiper/vue";

    import ProductCard from "../components/ProductCard.vue";
    import Review from "../components/Review.vue";
    import ReviewRatings from "../components/ReviewRatings.vue";
    import {
        useAuth
    } from "../stores/AuthStore";
    import {
        useBasketStore
    } from "../stores/BasketStore";
    import SkeletonLoader from "../components/SkeletonLoader.vue";

    import $ from 'jquery';
    // Import Swiper styles
    import "swiper/css";
    import "swiper/css/free-mode";
    import "swiper/css/navigation";
    import "swiper/css/thumbs";

    import {
        useToast
    } from "vue-toastification";





    const toast = useToast();

    const thumbsSwiper = ref(null);

    const modules = [FreeMode, Navigation, Thumbs];

    const setThumbsSwiper = (swiper) => {
        thumbsSwiper.value = swiper;
    };

    const route = useRoute();
    const router = useRouter();
    const masterStore = useMaster();
    const basketStore = useBasketStore();
    const authStore = useAuth();

    const formData = ref({
        product_id: route.params.id,
        size: null,
        color: null,
        unit: null,
    });

    const product = ref({});
    const productPrice = ref(0);
    const mainPrice = ref(0);
    const discountPercentage = ref(0);

    const relatedProducts = ref([]);
    const popularProducts = ref([]);

    const aboutProduct = ref(true);
    const review = ref(false);

    const cartProduct = ref(null);
    const isLoading = ref(true);
    const copied = ref(false);

    onMounted(() => {
        fetchProductDetails();
        window.scrollTo(0, 0);
        findProductInCart(route.params.id, formData.value.color);
    });

    watch(formData, () => {
        calculateProductPrice();
    }, {
        deep: true
    });


    const copyUrl = async () => {
        try {
            await navigator.clipboard.writeText(window.location.href);
            const content = {
                component: ToastSuccessMessage,
                props: {
                    title: 'Product Copied',
                    message: 'Product Url is copied in clipboard successfully',
                },
            };
            toast(content, {
                type: "default",
                hideProgressBar: true,
                icon: false,
                position: "top-right",
                toastClassName: "vue-toastification-alert",
                timeout: 3000
            });

        } catch (e) {
            console.error("Failed to copy URL", e);
            toast("Failed to copy URL!", {
                type: "error"
            });
        }
    };


    const calculateProductPrice = () => {
        var colorPrice = 0;
        var sizePrice = 0;

        const color = product.value.colors?.find((color) => color.id == formData.value.color);
        const size = product.value.sizes?.find((size) => size.id == formData.value.size);

        if (color) {
            colorPrice = color.price ?? 0;
        }
        if (size) {
            sizePrice = size.price ?? 0;
        }

        if (product.value.discount_price > 0) {
            productPrice.value = product.value.discount_price + colorPrice + sizePrice;
            mainPrice.value = product.value.price + colorPrice + sizePrice;
        } else {
            productPrice.value = product.value.price + colorPrice + sizePrice;
            mainPrice.value = productPrice.value;
        }

        discountPercentage.value = (((mainPrice.value - productPrice.value) / mainPrice.value) * 100).toFixed(2);
    }


    const buyNow = () => {
        if (authStore.token === null) {
            return (authStore.loginModal = true);
        }
        basketStore.addToCart({
            product_id: formData.value.product_id,
            is_buy_now: true,
            quantity: 1,
            size: formData.value.size,
            color: formData.value.color,
            unit: null
        }, {
            ...product.value,
            color: product.value.colors?.find(c => c.id === formData.value.color) || {
                id: formData.value.color
            }
        });

        basketStore.buyNowShopId = product.value?.shop.id;
        router.push({
            name: "buynow"
        });
    };

    watch(route, async () => {
        await nextTick();
        window.scrollTo(0, 0);
        fetchProductDetails();
        aboutProduct.value = true;
        review.value = false;
        formData.value.product_id = route.params.id;
        findProductInCart(route.params.id, formData.value.color);
    });

    watch(() => basketStore.products, () => {
        findProductInCart(route.params.id, formData.value.color);
    }, {
        deep: true
    });

    const findProductInCart = (productId, colorId) => {
        let foundProduct = null;
        basketStore.products.forEach((item) => {
            item.products.find((product) => {
                if (product.id == productId && product.color?.id == colorId) {
                    foundProduct = product;
                    return true;
                }
            });
        });
        cartProduct.value = foundProduct;
        if (foundProduct) {
            formData.value.size = foundProduct.size?.id;
            formData.value.color = foundProduct.color?.id;
            formData.value.unit = foundProduct.unit;
        }
    };

    const addToCart = () => {
        basketStore.addToCart(formData.value, {
            ...product.value,
            color: product.value.colors?.find(c => c.id === formData.value.color) || {
                id: formData.value.color
            }
        });
        setTimeout(() => {
            findProductInCart(route.params.id, formData.value.color);
        }, 200);
    };

    const decrementQty = () => {
        basketStore.decrementQuantity(product.value);
        setTimeout(() => {
            findProductInCart(route.params.id, formData.value.color);
        }, 200);
    };

    const incrementQty = () => {
        basketStore.incrementQuantity(product.value);
        setTimeout(() => {
            findProductInCart(route.params.id, formData.value.color);
        }, 200);
    };

    const favoriteAddOrRemove = () => {
        if (authStore.token === null) {
            return (authStore.loginModal = true);
        }
        axios.post('/favorite-add-or-remove', {
            product_id: product.value.id
        }, {
            headers: {
                Authorization: authStore.token
            }
        }).then(() => {
            product.value.is_favorite = !product.value.is_favorite
            if (product.value.is_favorite === false) {
                const content = {
                    component: ToastSuccessMessage,
                    props: {
                        title: 'Product removed from favorite',
                        message: 'Product removed from favorite successfully',
                    },
                };
                toast(content, {
                    type: "default",
                    hideProgressBar: true,
                    icon: false,
                    position: "top-right",
                    toastClassName: "vue-toastification-alert",
                    timeout: 3000
                });
            } else {
                const content = {
                    component: ToastSuccessMessage,
                    props: {
                        title: 'Product added to favorite',
                        message: 'Product added to favorite successfully',
                    },
                };
                toast(content, {
                    type: "default",
                    hideProgressBar: true,
                    icon: false,
                    position: "top-right",
                    toastClassName: "vue-toastification-alert",
                    timeout: 3000
                });
            }
            authStore.fetchFavoriteProducts();
        }).catch((error) => {
            console.log(error);
        });
    };

    const showReview = () => {
        aboutProduct.value = false;
        review.value = true;
        fetchReviews();
    };


    const flashSale = ref({});
    const fetchProductDetails = async () => {
        isLoading.value = true;
        axios.get("/product-details", {
            params: {
                product_id: route.params.id
            },
            headers: {
                Authorization: authStore.token,
            },
        }).then((response) => {
            product.value = response.data.data.product;
            relatedProducts.value = response.data.data.related_products;
            popularProducts.value = response.data.data.popular_products;
            flashSale.value = response.data.data.product.flash_sale;


            if (response) {
                startCountdown();
            }

            if (product.value.colors.length > 0) {
                formData.value.color = product.value.colors[0].id;
            } else {
                formData.value.color = null;
            }
            if (product.value.sizes.length > 0) {
                formData.value.size = product.value.sizes[0].id;
            } else {
                formData.value.size = null;
            }
            calculateProductPrice();
            findProductInCart(route.params.id);

            setTimeout(() => {
                isLoading.value = false;
            }, 100);
        });
    };

    const averageRatings = ref({});

    const totalReviews = ref(0);
    const reviews = ref([]);

    const currentPage = ref(1);
    const perPage = ref(6);

    const onClickHandler = (page) => {
        currentPage.value = page;
        fetchReviews();
    };

    const fetchReviews = async () => {
        axios.get("/reviews", {
            params: {
                product_id: route.params.id,
                page: currentPage.value,
                per_page: perPage.value,
            },
        }).then((response) => {
            totalReviews.value = response.data.data.total;
            reviews.value = response.data.data.reviews;
            averageRatings.value = response.data.data.average_rating_percentage;
        });
    };


    const endDay = ref("");
    const endHour = ref("");
    const endMinute = ref("");
    const endSecond = ref("");
    let countdownInterval = null;

    const startCountdown = () => {
        const endDate = new Date(flashSale.value?.end_date).getTime();

        if (flashSale.value?.end_date) {
            countdownInterval = setInterval(() => {
                const now = new Date().getTime();
                const timeLeft = endDate - now;

                if (timeLeft <= 0) {
                    clearInterval(countdownInterval);
                    endDay.value = "00";
                    endHour.value = "00";
                    endMinute.value = "00";
                    endSecond.value = "00";
                } else {
                    endDay.value = String(Math.floor(timeLeft / (1000 * 60 * 60 * 24))).padStart(2, "0");
                    endHour.value = String(Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 *
                        60))).padStart(2, "0");
                    endMinute.value = String(Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60)))
                        .padStart(2, "0");
                    endSecond.value = String(Math.floor((timeLeft % (1000 * 60)) / 1000)).padStart(2, "0");
                }
            }, 1000);
        }
    };

    onUnmounted(() => {
        clearInterval(countdownInterval);
    });

    // Position variables to control zoom position
    const mouseX = ref(0);
    const mouseY = ref(0);

    const handleMouseMove = (event) => {
        const container = event.currentTarget;
        const rect = container.getBoundingClientRect();

        let clientX, clientY;
        if (event.type === "touchmove" || event.type === "touchstart") {
            const touch = event.touches[0];
            clientX = touch.clientX;
            clientY = touch.clientY;
        } else {
            clientX = event.clientX;
            clientY = event.clientY;
        }

        // Calculate mouse position as a percentage of the container dimensions
        mouseX.value = ((clientX - rect.left) / rect.width) * 100;
        mouseY.value = ((clientY - rect.top) / rect.height) * 100;
    };

    const resetZoom = () => {
        mouseX.value = 50;
        mouseY.value = 50;
    };

    watch([mouseX, mouseY], ([x, y]) => {
        document.documentElement.style.setProperty('--mouse-x', `${x}%`);
        document.documentElement.style.setProperty('--mouse-y', `${y}%`);
    });

    let showcolordiv = 0;


    $(document).ready(function() {
        // Handle go back
        $(document).on('click', '.changeshowcolordiv', function() {
            $('#customdiv').hide();
            $('#swipperdiv').show();
        });
    });

    const selectedImage = ref('');
    $('#customdiv').hide();

    function updateImage(image) {
        selectedImage.value = image;
        $('#customdiv').show();
        $('#swipperdiv').hide();
    }
</script>



<style scoped>
    .zoom-container {
        overflow: hidden;
        position: relative;
        cursor: zoom-in;
        width: 100%;
        height: 100%;
    }

    .zoom-image {
        transition: transform 0.3s ease, transform-origin 0.3s ease;
        transform: scale(1);
        transform-origin: center center;
    }

    .zoom-container:hover .zoom-image {
        transform: scale(3.5);
        transform-origin: calc(var(--mouse-x, 50%)) calc(var(--mouse-y, 50%));
    }
</style>

<style>
    .description img {
        max-width: 95% !important;
    }

    iframe {
        width: 100%;
        height: 300px !important;
    }

    @media(max-width:500px) {
        iframe {
            height: 200px !important;
        }
    }

    @media(max-width:375px) {
        iframe {
            height: 180px !important;
        }
    }

    @media(max-width:320px) {
        iframe {
            height: 160px !important;
        }
    }

    .product-details-slider .swiper-slide {
        height: auto !important;
    }

    .product-details-thumbnail .swiper-slide {
        @apply h-20 md:h-[120px] lg:h-[100px];
    }

    .product-details-thumbnail .swiper-button-prev,
    .product-details-thumbnail .swiper-button-next {
        @apply bg-white w-6 h-6 rounded-full shadow border border-slate-200 text-slate-600 -translate-y-1/2 mt-0;
    }

    .product-details-thumbnail .swiper-button-prev::after,
    .product-details-thumbnail .swiper-button-next::after {
        @apply text-base;
    }

    .product-details-thumbnail .swiper-button-next {
        right: 0px;
    }

    .product-details-thumbnail .swiper-button-prev {
        left: 0px;
    }

    .product-details-thumbnail .swiper-slide {
        @apply border border-slate-100 rounded-lg transition overflow-hidden;
    }

    .product-details-thumbnail .swiper-slide-thumb-active {
        @apply border border-primary;
    }
</style>
