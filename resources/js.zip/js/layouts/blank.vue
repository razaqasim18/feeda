<template>
    <slot />
</template>
